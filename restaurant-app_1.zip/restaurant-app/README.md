# 附近吃什么

翻卡片找餐厅。基于你的实时位置 + Google Places 真实数据。

## 部署步骤（10分钟）

### 1. 上传到 GitHub
1. 去 github.com → 新建仓库（New repository）
2. 名字随意，比如 `restaurant-app`
3. 把这个文件夹里的所有文件上传上去

### 2. 部署到 Vercel
1. 去 vercel.com，用 GitHub 登录
2. 点 "Add New Project" → 选你刚创建的仓库
3. **重要**：在 "Environment Variables" 里添加：
   - Key: `GOOGLE_PLACES_KEY`
   - Value: `AIzaSyD9E1mmcnpgM0v5g4vU1EgApsqLv5OS3kg`
4. 点 Deploy

### 3. 完成
几分钟后你会得到一个 `xxx.vercel.app` 的链接，手机打开即可使用。

## 功能
- 📍 自动获取位置，找附近餐厅
- 🃏 一张一张翻卡片
- 📱 左滑跳过，右滑导航（或拖动）
- ⏰ 显示今日营业时间
- ⭐ 真实评分和评价数
- 💰 价格等级
- 🚫 "跳过所有日料" 等类型过滤
